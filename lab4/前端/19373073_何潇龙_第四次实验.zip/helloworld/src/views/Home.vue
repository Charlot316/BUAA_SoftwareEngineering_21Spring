<template>
  <div class="home">
    <b v-if="!$store.state.isLogin" >
      尚未登录，请前往登录
      <router-link to="/login">Login</router-link>
    </b>
    <b v-else >已经登陆！</b>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  }
}
</script>
