<template>
  <div class="Login">
        <el-button v-if="!$store.state.isLogin" v-on:click="login" type="primary">
          登录
        </el-button>
        <el-button v-else v-on:click="logout" type="info">退出登录</el-button>
  </div>
</template>

<script>

export default{
    name:'Login',
    methods:{
        login(){
            this.$store.commit("login");
        },
        logout(){
            this.$store.commit("logout");
        },
    },
};
</script>

